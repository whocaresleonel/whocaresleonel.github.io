const { app, BrowserView, BrowserWindow, protocol, shell, nativeImage, Menu, dialog } = require("electron");
app.setName("FPS Desktop 2.0");
icon = nativeImage.createFromPath("icon.png");
const TruBar = require("electron-trubar");
app.dock.setIcon(icon);
require("v8-compile-cache");
files = [
  "package.json",
  "package-lock.json",
  "main.js",
  "assets/loading.png",
  "assets/loading.html",
  "icon.png",
]
function init(defView = null) {
  screen = require("electron").screen.getPrimaryDisplay().size;
  let mainWindow = new BrowserWindow({
    width: 1100,
    height: 750,
    center: true,
    hasShadow: true,
    frame: false,
    roundedCorners: false,
    titleBarStyle: "customButtonsOnHover",
    show: false,
    title: "FPS Desktop 2.0",
    icon: __dirname + "/icon.png",
    transparent: false,
    background: "#000",
    minWidth: 300,
    minHeight: 200
  });
  let view;
  if (!defView) {
    view = new BrowserView({
      webPreferences: {
        javascript: true,
        autoplayPolicy: "no-user-gesture-required",
        webgl: true
      }
    });
  }
  mainWindow.setIcon(__dirname + "/icon.png");
  mainWindow.setBrowserView(view);
  view.setBounds({ x: 0, y: 32, width: mainWindow.getSize()[0], height: mainWindow.getSize()[1] - 32 });
  view.webContents.loadFile("./assets/loading.html", {
    extraHeaders: "Referrer-Policy: origin"
  });
  app.setAppLogsPath(__dirname + "/logs");
  setTimeout(() => {
    view.webContents.loadURL("https://www.fps2.ml/", {
      extraHeaders: "Referrer-Policy: origin"
    });
  }, 3000);
  mainWindow.on("resize", () => {
    view.setBounds({ x: 0, y: 32, width: mainWindow.getSize()[0], height: mainWindow.getSize()[1] - 32 });
  });
  mainWindow.loadURL("about:blank");
  TruBar(mainWindow, {
    backgroundColor: "#fff",
    textColor: "#38b6ff",
    seam: true,
    seamColor: "#38b6ff",
    height: 20,
    trafficLightX: 6.5,
    trafficLightY: 6.5,
    title: "FPS Desktop 2.0"
  }, mainWindow, view);
  mainWindow.show();
  mainWindow.oldSize = mainWindow.getSize();
  mainWindow.oldPos = mainWindow.getPosition();
  mainWindow.altFullScreen = (e = true) => (e ? (mainWindow.oldSize = mainWindow.getSize(), mainWindow.oldPos = mainWindow.getPosition(), mainWindow.setSize(screen.width, screen.height), mainWindow.center(), mainWindow.setResizable(false)) : ((mainWindow.setSize(mainWindow.oldSize[0], mainWindow.oldSize[1]), mainWindow.setResizable(true))), mainWindow.center());
  view.webContents.on("did-finish-load", (e) => {
    (e.sender.getURL().includes("src.html")) ? setTimeout(() => mainWindow.altFullScreen(true), 10000) : mainWindow.altFullScreen(false);
  });
  app.dock.setMenu(Menu.buildFromTemplate([{
    label: "Window options",
    submenu: [
      {
        label: "Close",
        click() { mainWindow.close() }
      },
      {
        label: "Unmaximize",
        click() { mainWindow.unmaximize() }
      },
      {
        label: "Maximize",
        click() { mainWindow.maximize() }
      },
      {
        label: "Open alias",
        click() { init(view) }
      },
      {
        label: "Strong reload",
        click() {
          dialog.showMessageBox(mainWindow, {
            icon: icon,
            title: "Strong reload",
            message: "Running a strong reload will clear all cache, temporary files/logs, and refresh ALL settings. Do you want to continue?",
            buttons: ["Cancel", "OK"]
          }).then((e) => {
            if (e.response == 1) {
              files.forEach(x => {
                let window = new BrowserWindow({ show: false });
                window.loadFile("./" + x);
                window.webContents.executeJavaScript("location.reload(true)");
                window.close();
              });
              app.clearRecentDocuments();
              mainWindow.setPosition(mainWindow.getPosition()[0], -mainWindow.getSize()[1], true);
              setTimeout(() => {
                mainWindow.close();
                app.quit();
              }, 1000);
            }
          })
        }
      }
    ]
  }]));
}
app.on("ready", () => init());